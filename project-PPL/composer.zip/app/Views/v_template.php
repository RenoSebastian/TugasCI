<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Template Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        /* Custom styles */
        body {
            padding-top: 20px; /* Add padding to the top of the body */
            padding-bottom: 20px; /* Add padding to the bottom of the body */
        }
        .container {
            width: 90%; /* Set width to 90% */
            margin: auto; /* Center the container */
        }
        footer {
            margin-top: 20px; /* Add margin to the top of the footer */
            text-align: center; /* Center align the content in the footer */
        }
    </style>
</head>
<body>
    <header>
        <!-- Header Content -->
        <?= $this->renderSection('header') ?>
    </header>

    <nav>
        <!-- Navbar Content -->
        <?= $this->renderSection('navbar') ?>
    </nav>

    <main>
        <div class="container">
            <!-- Main Content -->
            <?= $this->renderSection('content') ?>
        </div>
    </main>

    <footer>
        <!-- Footer Content -->
        <?= $this->renderSection('footer') ?>

        <!-- Logout Button -->
        <form action="/logout" method="post">
            <button type="submit" class="btn btn-danger">Logout</button>
        </form>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
