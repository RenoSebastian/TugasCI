<?php

namespace App\Controllers;

class coba extends BaseController
{
    public function display()
    {
       echo('hello_world');
    }
}